llistadetuples=[(15, 62), (24, 77), (32, 78), (29, 57), (32, 95), (32, 76), (19, 80), (32, 54), (17, 81), (22, 70)]

temperatura = []
humitat = []



for tupla in llistadetuples:
    temperatura.append(tupla[0])
    humitat.append(tupla[1])


    
